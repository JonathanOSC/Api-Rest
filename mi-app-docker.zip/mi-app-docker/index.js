const express = require('express');
const app = express();

app.use(express.json());

// ─── DATOS ───────────────────────────────────────────────────────
let libros = [
  { id: 1, titulo: 'Cien años de soledad', autor: 'Gabriel García Márquez', año: 1967, disponible: true },
  { id: 2, titulo: 'El amor en los tiempos del cólera', autor: 'Gabriel García Márquez', año: 1985, disponible: false },
  { id: 3, titulo: 'La hojarasca', autor: 'Gabriel García Márquez', año: 1955, disponible: true },
];
let nextId = 4;
// ─────────────────────────────────────────────────────────────────

// GET todos
app.get('/libros', (req, res) => {
  res.json(libros);
});

// GET por id
app.get('/libros/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const libro = libros.find(l => l.id === id);
  if (!libro) return res.status(404).json({ error: `No se encontró el libro con id ${id}` });
  res.json(libro);
});

// POST crear
app.post('/libros', (req, res) => {
  const { titulo, autor, año, disponible } = req.body;
  if (!titulo || !autor) return res.status(400).json({ error: 'titulo y autor son obligatorios' });
  const nuevo = { id: nextId++, titulo, autor, año: año || null, disponible: disponible !== undefined ? disponible : true };
  libros.push(nuevo);
  res.status(201).json(nuevo);
});

// PUT actualizar
app.put('/libros/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const index = libros.findIndex(l => l.id === id);
  if (index === -1) return res.status(404).json({ error: `No se encontró el libro con id ${id}` });
  const { titulo, autor, año, disponible } = req.body;
  if (!titulo || !autor) return res.status(400).json({ error: 'titulo y autor son obligatorios' });
  libros[index] = { id, titulo, autor, año, disponible };
  res.json(libros[index]);
});

// DELETE eliminar
app.delete('/libros/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const index = libros.findIndex(l => l.id === id);
  if (index === -1) return res.status(404).json({ error: `No se encontró el libro con id ${id}` });
  const eliminado = libros.splice(index, 1)[0];
  res.json({ mensaje: 'Registro eliminado', eliminado });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`API corriendo en http://localhost:${PORT}`));