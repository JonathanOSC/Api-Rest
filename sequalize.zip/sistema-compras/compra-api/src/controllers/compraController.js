const Compra = require('../models/compra');
const { obtenerCliente } = require('../services/clienteService');
const { obtenerProducto } = require('../services/productoService');

// Formatea una fila de Compra al shape de respuesta esperado
function formatearCompra(compra) {
  return {
    id: compra.id_compras,
    clienteId: compra.id_clientes,
    productoId: compra.id_productos,
    total: compra.total,
    fecha: compra.fecha_compra,
  };
}

const compraController = {
  // GET /compras
  async obtenerCompras(req, res) {
    try {
      const compras = await Compra.findAll({
        order: [['id_compras', 'ASC']],
      });
      res.status(200).json(compras.map(formatearCompra));
    } catch (error) {
      res.status(500).json({ mensaje: 'No se pudieron obtener las compras' });
    }
  },

  // GET /compras/:id
  async obtenerCompraPorId(req, res) {
    const id = Number(req.params.id);

    try {
      const compra = await Compra.findByPk(id);

      if (!compra) {
        return res.status(404).json({ mensaje: 'Compra no encontrada' });
      }

      res.status(200).json(formatearCompra(compra));
    } catch (error) {
      res.status(500).json({ mensaje: 'No se pudo obtener la compra' });
    }
  },

  // POST /compras
  async crearCompra(req, res) {
    const { clienteId, productoId, cantidad } = req.body;

    if (!clienteId || !productoId || !cantidad) {
      return res.status(400).json({
        mensaje: "Los campos 'clienteId', 'productoId' y 'cantidad' son obligatorios",
      });
    }

    let cliente;
    let producto;

    try {
      cliente = await obtenerCliente(clienteId);
      producto = await obtenerProducto(productoId);
    } catch (error) {
      return res.status(503).json({
        mensaje: 'No se pudo validar la compra porque uno de los servicios no respondió',
        detalle: error.message,
      });
    }

    if (!cliente) {
      return res.status(404).json({ mensaje: `El cliente ${clienteId} no existe` });
    }

    if (!producto) {
      return res.status(404).json({ mensaje: `El producto ${productoId} no existe` });
    }

    if (producto.stock < cantidad) {
      return res.status(400).json({
        mensaje: `Stock insuficiente. Disponible: ${producto.stock}, solicitado: ${cantidad}`,
      });
    }

    try {
      const nuevaCompra = await Compra.create({
        id_clientes: clienteId,
        id_productos: productoId,
        total: producto.precio * cantidad,
        fecha_compra: new Date(),
      });

      res.status(201).json(formatearCompra(nuevaCompra));
    } catch (error) {
      res.status(500).json({
        mensaje: 'No se pudo crear la compra' + (error.message ? `: ${error.message}` : ''),
      });
    }
  },

  // PUT /compras/:id
  async actualizarCompra(req, res) {
    const id = Number(req.params.id);
    const { clienteId, productoId, total } = req.body;

    if (!Number.isInteger(id) || !clienteId || !productoId || total === undefined) {
      return res.status(400).json({
        mensaje: "El id, 'clienteId', 'productoId' y 'total' son obligatorios",
      });
    }

    try {
      const [filas] = await Compra.update(
        { id_clientes: clienteId, id_productos: productoId, total },
        { where: { id_compras: id } }
      );

      if (filas === 0) {
        return res.status(404).json({ mensaje: 'Compra no encontrada' });
      }

      const compraActualizada = await Compra.findByPk(id);
      res.status(200).json(formatearCompra(compraActualizada));
    } catch (error) {
      if (error.parent && error.parent.code === '23503') {
        return res.status(400).json({
          mensaje: 'El cliente o producto indicado no existe',
        });
      }

      res.status(500).json({ mensaje: 'No se pudo actualizar la compra' });
    }
  },

  // DELETE /compras/:id
  async eliminarCompra(req, res) {
    const id = Number(req.params.id);

    if (!Number.isInteger(id)) {
      return res.status(400).json({ mensaje: 'El id de la compra no es válido' });
    }

    try {
      const compra = await Compra.findByPk(id);

      if (!compra) {
        return res.status(404).json({ mensaje: 'Compra no encontrada' });
      }

      await compra.destroy();

      res.status(200).json({ mensaje: 'Compra eliminada', compra: formatearCompra(compra) });
    } catch (error) {
      res.status(500).json({ mensaje: 'No se pudo eliminar la compra' });
    }
  },
};

module.exports = compraController;
